package com.lbe.security.service.battery.util;

public class BatteryCapacityGuessTest {

	public static void main(String[] args) {
		System.out.println (Integer.toString(BatteryCapacityGuess.getBatteryCapacity("Gionee", "L601", 1000)));
	}

}
